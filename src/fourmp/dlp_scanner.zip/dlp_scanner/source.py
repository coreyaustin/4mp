"""DLP projector model: a pinhole 'inverse camera' that emits a scan-line pattern."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .geometry import Pose, look_at_pose
from .patterns import SourcePattern
from .sut import SutHit, SutWorld


@dataclass
class Source:
    pose: Pose
    resolution: tuple[int, int]  # (rows, cols)
    fov_deg: tuple[float, float]  # (horizontal, vertical) full field of view
    pattern: SourcePattern

    @classmethod
    def at(
        cls,
        position,
        target=(0.0, 0.0, 0.0),
        resolution=(60, 64),
        fov_deg=(24.0, 18.0),
        pattern: SourcePattern | None = None,
        world_up=(0.0, 0.0, 1.0),
    ) -> "Source":
        # world_up = the table's Z spin axis (the natural "up" for how this rig gets
        # mounted). With a horizontal source/camera baseline, that keeps a scan line's
        # row-plane normal aligned with the baseline instead of perpendicular to it —
        # see `row_plane` — which is what keeps triangulation well-conditioned.
        pose = look_at_pose(position, target, world_up=world_up)
        return cls(pose=pose, resolution=resolution, fov_deg=fov_deg, pattern=pattern or SourcePattern.all_on(resolution))

    def _tan_half_fov(self):
        fx, fy = self.fov_deg
        return np.tan(np.radians(fx) / 2), np.tan(np.radians(fy) / 2)

    def pixel_direction_world(self, row: float, col: float) -> np.ndarray:
        rows, cols = self.resolution
        tx, ty = self._tan_half_fov()
        u = ((col + 0.5) / cols * 2 - 1) * tx
        v = ((row + 0.5) / rows * 2 - 1) * ty
        d_local = np.array([u, -v, 1.0])
        d_local = d_local / np.linalg.norm(d_local)
        return self.pose.direction_to_world(d_local)

    def row_plane(self, row: float):
        """World-space plane swept by a single DMD row (all columns) — the plane a
        projected scan line traces through the projector's optical center."""
        _, cols = self.resolution
        d_left = self.pixel_direction_world(row, 0)
        d_right = self.pixel_direction_world(row, cols - 1)
        normal = np.cross(d_left, d_right)
        norm = np.linalg.norm(normal)
        if norm < 1e-9:
            return None
        return self.pose.position, normal / norm

    def project(self, sut_world: SutWorld) -> list["SourceHit"]:
        """Cast a ray per active source pixel and find where it hits the SUT."""
        rows, cols = self.resolution
        hits = []
        for row in range(rows):
            for col in range(cols):
                intensity = self.pattern.image[row, col]
                if intensity <= 0.0:
                    continue
                direction = self.pixel_direction_world(row, col)
                hit = sut_world.intersect_ray(self.pose.position, direction)
                if hit is None:
                    continue
                hits.append(SourceHit(row=row, col=col, intensity=float(intensity), sut_hit=hit))
        return hits


@dataclass
class SourceHit:
    row: int
    col: int
    intensity: float
    sut_hit: SutHit
